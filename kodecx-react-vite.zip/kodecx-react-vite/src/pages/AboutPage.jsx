import React from 'react';
import { Code2, ShieldCheck, Zap, Award, Target, Users, Phone, MessageSquare } from 'lucide-react';

export function AboutPage({ onNavigate }) {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-16">
      {/* Brand Profile */}
      <div className="text-center space-y-4">
        <img 
          src="https://i.ibb.co/3yyH3cKS/1781110845060.png" 
          alt="Kodecx Logo" 
          className="w-20 h-20 rounded-full border-4 border-orange-500 mx-auto shadow-xl"
        />
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          About Kodecx Enterprises
        </h1>
        <p className="text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Founded and led by <strong>Chijioke Igbo</strong>, Kodecx Enterprises specializes in developing modern digital templates, high-conversion commercial landing pages, and bespoke web platforms for ambitious businesses.
        </p>
      </div>

      {/* Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
            <Code2 className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Clean Engineering</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every file in our templates is hand-crafted with semantic markup, modern CSS, modular architecture, and zero unnecessary dependencies.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Conversion Focus</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            We don&rsquo;t just make things look pretty; our layouts are specifically tuned to turn casual visitors into paying customers and qualified leads.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Frictionless Security</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Integrated with Paystack for secure African and international payments, Firebase for cloud data synchronization, and automated email fulfillment.
          </p>
        </div>
      </div>

      {/* Direct Developer Contact CTA */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4">
        <h3 className="text-xl font-bold text-white">Have Questions or Need Direct Help?</h3>
        <p className="text-xs text-slate-400 max-w-lg mx-auto">
          We pride ourselves on direct, responsive customer support. Speak with our lead developer on WhatsApp for template inquiries or custom proposals.
        </p>
        <div className="flex flex-wrap justify-center gap-3 pt-2">
          <a
            href="https://wa.me/2349071967004"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-5 rounded-xl text-xs flex items-center gap-2 cursor-pointer transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            <span>WhatsApp (+234 907 196 7004)</span>
          </a>
          <button
            onClick={() => onNavigate('contact')}
            className="bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 px-5 rounded-xl text-xs cursor-pointer transition-colors"
          >
            View Contact Details
          </button>
        </div>
      </div>
    </div>
  );
}
