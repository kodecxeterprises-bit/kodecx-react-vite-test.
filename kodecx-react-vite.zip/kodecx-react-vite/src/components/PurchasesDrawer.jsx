import React from 'react';
import { X, Download, FileCode, ExternalLink, PackageCheck, AlertCircle } from 'lucide-react';

export function PurchasesDrawer({
  isOpen,
  onClose,
  purchases
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2">
            <PackageCheck className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-extrabold text-white">My Purchased Downloads</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800/80 rounded-full cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {(!purchases || purchases.length === 0) ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-800/60 flex items-center justify-center">
                <FileCode className="w-8 h-8 text-slate-500" />
              </div>
              <div>
                <p className="font-bold text-white text-sm">No purchases recorded yet</p>
                <p className="text-xs text-slate-500 mt-1">
                  Once you complete a purchase, your Google Drive download link will appear here instantly.
                </p>
              </div>
            </div>
          ) : (
            purchases.map((item, idx) => (
              <div 
                key={idx}
                className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-2 hover:border-orange-500/40 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-sm font-bold text-white">{item.title}</h4>
                  <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                    Paid
                  </span>
                </div>

                {item.purchasedAt && (
                  <span className="text-[10px] text-slate-500">
                    Acquired on {new Date(item.purchasedAt).toLocaleDateString()}
                  </span>
                )}

                {item.link ? (
                  <a
                    href={item.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 bg-orange-500/20 hover:bg-orange-500 text-orange-300 hover:text-white border border-orange-500/40 font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Source Code (Google Drive)</span>
                    <ExternalLink className="w-3 h-3 ml-auto opacity-70" />
                  </a>
                ) : (
                  <p className="text-xs text-slate-500 italic mt-1">
                    Download link delivered via email confirmation.
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
