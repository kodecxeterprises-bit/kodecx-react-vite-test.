import React from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  CreditCard, 
  MessageSquare, 
  ShoppingBag,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { formatPrice } from '../services/currency';

export function CartDrawer({
  isOpen,
  onClose,
  cart,
  currentCurrency,
  onUpdateQuantity,
  onRemoveItem,
  onCheckoutPaystack
}) {
  if (!isOpen) return null;

  const totalNaira = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const itemSummary = cart
    .map(i => `• ${i.title} (${i.quantity}x) - ${formatPrice(i.price * i.quantity, currentCurrency)}`)
    .join('\n');
  const waText = `Hello! I would like to checkout my cart:\n\n${itemSummary}\n\nTotal: ${formatPrice(totalNaira, currentCurrency)}`;
  const waUrl = `https://wa.me/2349071967004?text=${encodeURIComponent(waText)}`;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-extrabold text-white">Your Shopping Cart</h2>
            <span className="bg-orange-500/20 text-orange-400 text-xs font-bold px-2 py-0.5 rounded-full">
              {cart.reduce((sum, i) => sum + i.quantity, 0)} items
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800/80 rounded-full cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Item List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-800/60 flex items-center justify-center">
                <ShoppingBag className="w-8 h-8 text-slate-500" />
              </div>
              <div>
                <p className="font-bold text-white text-sm">Your cart is empty</p>
                <p className="text-xs text-slate-500 mt-1">Explore our catalog and pick production-ready templates.</p>
              </div>
            </div>
          ) : (
            cart.map((item) => (
              <div 
                key={item.id} 
                className="bg-slate-950 border border-slate-800/80 rounded-2xl p-3 flex gap-3 items-center"
              >
                <div className="w-16 h-16 rounded-xl bg-slate-900 overflow-hidden flex-shrink-0 border border-slate-800">
                  {item.video ? (
                    <video src={item.video} muted className="w-full h-full object-cover" />
                  ) : (
                    <img src={item.images?.[0]} alt={item.title} className="w-full h-full object-cover" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                  <span className="text-xs font-black text-orange-400 block mt-0.5">
                    {formatPrice(item.price * item.quantity, currentCurrency)}
                  </span>
                  
                  {/* Quantity controls */}
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                      className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-bold text-white min-w-[16px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                      className="p-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => onRemoveItem(item.id)}
                  className="p-2 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                  title="Remove item"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Checkout Footer */}
        {cart.length > 0 && (
          <div className="p-5 bg-slate-950 border-t border-slate-800 space-y-3">
            <div className="flex items-baseline justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Amount:</span>
              <span className="text-2xl font-black text-orange-500">
                {formatPrice(totalNaira, currentCurrency)}
              </span>
            </div>

            <div className="space-y-2">
              <button
                onClick={onCheckoutPaystack}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-extrabold py-3.5 px-4 rounded-xl shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
              >
                <CreditCard className="w-4 h-4" />
                <span>Pay Cart with Paystack</span>
              </button>

              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer text-xs"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Checkout Cart via WhatsApp</span>
              </a>
            </div>

            <p className="text-[10px] text-center text-slate-500 flex items-center justify-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Multi-account EmailJS dispatch automatically triggers after payment.</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
