# Kodecx Enterprises - Premium React + Vite Web Platform

A production-grade, high-performance web platform built with **React 19**, **Vite 6**, and **Tailwind CSS**. Migrated from the original single-file implementation into a modular, enterprise architecture while strictly preserving 100% of the business logic, product data, multi-account EmailJS automations, Paystack checkout, Firebase authentication, and Firestore purchase history.

---

## 🚀 Key Features Preserved & Enhanced

1. **Digital Templates Storefront**:
   - 10 full-featured digital website templates with live media previews (screenshots & demo videos).
   - Instant search and instant category filter chips (All, E-Commerce, Business, Portfolio, Gaming, Automotive, Entertainment, Education, Social Media).
   - Price sorting and live inventory preview.
   - Rich interactive detail modal with interactive media galleries and zoom lightbox.

2. **Multi-Currency System with Live Geo-Detection**:
   - Supports 🇳🇬 NGN (₦), 🇺🇸 USD ($), 🇬🇭 GHS (₵), 🇿🇦 ZAR (R), and 🇰🇪 KES (KSh).
   - Live exchange rates fetched via Open ER-API (`open.er-api.com/v6/latest/NGN`) with reliable fallback rates.
   - Automatic local currency detection by IP geolocation (`ipapi.co/json`).

3. **Paystack Checkout Integration**:
   - Single-product instant Paystack inline popup.
   - Multi-item shopping cart Paystack inline checkout with aggregated kobo calculation.
   - Pre-payment persistence to `localStorage` (`kodecx_pending_order`) for seamless pending order recovery if the browser is closed or refreshed during checkout.

4. **Multi-Account EmailJS Routing**:
   - Individual product-to-account configuration mapping across 5 distinct EmailJS service accounts.
   - Rate-limiting delay (1.1s) to prevent spam filtering during multi-item cart purchases.
   - Specialized rules: *Link In Bio* template download URLs are delivered exclusively via email and never auto-opened in the browser.

5. **Firebase Authentication & Firestore Purchase History**:
   - Google Sign-In with popup.
   - Email/password user registration and login.
   - Real-time `onSnapshot` listener syncing customer downloads from `users/{uid}` in Cloud Firestore.
   - Dedicated "My Downloads" slide-over drawer for instant access to purchased Google Drive source archives.

6. **Custom Web & App Development Services**:
   - Interactive project quote / budget estimator.
   - High-conversion call-to-action routing directly to WhatsApp (+234 907 196 7004).

7. **Customer Support & AI Chat Widgets**:
   - Floating interactive Ragmy AI Assistant modal widget.
   - Tawk.to live customer support script integration.

8. **Secure Server-Side Payment Verification**:
   - Includes Netlify Serverless Function (`netlify/functions/verify-payment.js`) for server-side Paystack verification.
   - Never exposes Paystack secret keys in frontend client code.

---

## 🛠️ Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Fill in your Paystack public key, Firebase configuration, and optional backend verification endpoint.

### 3. Start Development Server
```bash
npm run dev
```
Open your browser at `http://localhost:3000`.

### 4. Build for Production
```bash
npm run build
```
The compiled, production-ready assets will be generated in `dist/`.

---

## 📂 Project Architecture

```
kodecx-react-vite/
├── .env.example                # Documented environment variables template
├── .gitignore                  # Git ignore rules
├── index.html                  # HTML entry point with Paystack SDK & fonts
├── netlify.toml                # Netlify deployment and function redirect rules
├── package.json                # Project dependencies and npm scripts
├── README.md                   # Complete documentation
├── vite.config.js              # Vite + Tailwind configuration
├── netlify/
│   └── functions/
│       └── verify-payment.js   # Serverless Paystack verification endpoint
├── public/                     # Static assets and icons
└── src/
    ├── main.jsx                # Application React bootstrap
    ├── App.jsx                 # Root component with routing and modal orchestrator
    ├── assets/                 # Brand assets
    ├── data/
    │   └── products.js         # Complete 10-template catalog and EmailJS configs
    ├── services/
    │   ├── currency.js         # Exchange rates and currency formatter
    │   ├── emailjs.js          # Multi-account EmailJS delivery engine
    │   ├── firebase.js         # Firebase Auth and Firestore persistence
    │   ├── paystack.js         # Paystack popup launcher and callbacks
    │   └── recovery.js         # Pending order recovery logic
    ├── styles/
    │   └── index.css           # Tailwind CSS imports and custom animations
    ├── components/
    │   ├── AuthModal.jsx       # Google and Email authentication modal
    │   ├── Banner.jsx          # Top announcement banner
    │   ├── CartDrawer.jsx      # Slide-out shopping cart drawer
    │   ├── DownloadZipModal.jsx# Direct project source code ZIP downloader
    │   ├── Footer.jsx          # Brand footer with verified social media links
    │   ├── Lightbox.jsx        # Fullscreen media gallery lightbox
    │   ├── Navbar.jsx          # Sticky header with currency and cart badges
    │   ├── ProductCard.jsx     # Modern template card with video/image preview
    │   ├── ProductModal.jsx    # Detailed product showcase modal
    │   ├── PurchasesDrawer.jsx # Downloads drawer with Google Drive links
    │   ├── RagmyWidget.jsx     # Floating AI Assistant widget
    │   ├── TawkWidget.jsx      # Tawk.to live support script loader
    │   └── TrustStrip.jsx      # Trust badges and guarantees
    └── pages/
        ├── AboutPage.jsx       # Kodecx Enterprises story and principles
        ├── ContactPage.jsx     # Direct contact channels and WhatsApp links
        ├── CustomServicesPage.jsx# Custom web dev services and quote estimator
        ├── HomePage.jsx        # Hero section, featured templates, CTAs
        ├── PortfolioPage.jsx   # Genuine projects showcase
        └── StorePage.jsx       # Filterable catalog with search and sorting
```

---

## 🔒 Security Best Practices

- **Paystack Secret Keys**: Keep your `PAYSTACK_SECRET_KEY` strictly on your backend (e.g. Netlify Environment Variables or Node.js server). Never prefix with `VITE_`.
- **Payment Verification**: When deployed, requests to `/api/paystack/verify/:reference` route to `netlify/functions/verify-payment.js` which verifies transactions directly with `https://api.paystack.co/transaction/verify/${ref}` using your secret key.
