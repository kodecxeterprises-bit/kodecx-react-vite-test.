import React from 'react';
import { Zap, Sparkles } from 'lucide-react';

export function Banner({ onOpenDownloadModal }) {
  return (
    <div className="bg-gradient-to-r from-red-600 via-orange-600 to-amber-600 text-white text-xs font-bold py-2 px-4 shadow-sm relative z-30">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 tracking-wide mx-auto md:mx-0">
          <Zap className="w-3.5 h-3.5 animate-bounce text-yellow-300" />
          <span>INSTANT SOURCE CODE DOWNLOADS &bull; PRODUCTION-READY TEMPLATES &bull; 24/7 WHATSAPP SUPPORT</span>
        </div>
        <button 
          onClick={onOpenDownloadModal}
          className="hidden md:inline-flex items-center gap-1.5 bg-black/30 hover:bg-black/50 text-white text-[11px] font-semibold py-0.5 px-2.5 rounded-full border border-white/20 transition-all cursor-pointer"
        >
          <Sparkles className="w-3 h-3 text-amber-300" />
          <span>Export Source (.ZIP)</span>
        </button>
      </div>
    </div>
  );
}
