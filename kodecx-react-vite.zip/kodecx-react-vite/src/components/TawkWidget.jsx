import { useEffect } from 'react';

export function TawkWidget() {
  useEffect(() => {
    // Preserve customer support script integration
    if (window.__tawkLoaded) return;
    window.__tawkLoaded = true;

    window.Tawk_API = window.Tawk_API || {};
    window.Tawk_LoadStart = new Date();

    const s1 = document.createElement("script");
    s1.async = true;
    s1.src = 'https://embed.tawk.to/6ab945fb94ff003441c4d5e5/default';
    s1.charset = 'UTF-8';
    s1.setAttribute('crossorigin', '*');
    document.head.appendChild(s1);
  }, []);

  return null;
}
