import React from 'react';
import { Zap, Code2, Headphones, ShieldCheck, CheckCircle2 } from 'lucide-react';

export function TrustStrip() {
  const points = [
    { icon: Zap, text: "Instant Source Code Access" },
    { icon: Code2, text: "Production-Grade Clean Code" },
    { icon: Headphones, text: "Direct Developer WhatsApp Support" },
    { icon: ShieldCheck, text: "Verified Paystack Secure Checkout" }
  ];

  return (
    <div className="border-b border-slate-800 bg-slate-900/60 backdrop-blur-md py-2.5 px-4 text-xs font-medium text-slate-300">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-center md:justify-between gap-y-2 gap-x-6 text-center">
        {points.map((p, i) => (
          <div key={i} className="inline-flex items-center gap-2">
            <p.icon className="w-3.5 h-3.5 text-orange-500 flex-shrink-0" />
            <span className="font-semibold text-slate-200">{p.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
