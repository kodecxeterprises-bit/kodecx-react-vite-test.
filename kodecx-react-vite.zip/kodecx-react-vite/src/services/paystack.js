// Paystack Inline SDK Checkout & Order Recovery Persistence

import { 
  sendConfiguredPurchaseEmail, 
  processMultiAccountCheckout, 
  isLinkInBioProduct 
} from "./emailjs";
import { savePurchaseToFirestore } from "./firebase";
import { savePendingOrder, clearPendingOrder } from "./recovery";

export const PAYSTACK_PUBLIC_KEY = 
  import.meta.env.VITE_PAYSTACK_PUBLIC_KEY || "pk_live_7b30798585c571a43c33c6ebe72ecf63d6554d8e";

export function sanitizeEmail(email) {
  if (!email) return null;
  const cleaned = email.trim().toLowerCase();
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(cleaned) ? cleaned : null;
}

export function triggerSinglePaystack({
  product,
  user,
  onStart,
  onSuccess,
  onError,
  onCancel
}) {
  if (typeof window.PaystackPop === 'undefined') {
    alert("Paystack SDK is loading or unavailable. Please check your internet connection.");
    return;
  }

  let rawEmail = user?.email || prompt("Enter your email address to receive your source code:");
  if (!rawEmail) return;

  const customerEmail = sanitizeEmail(rawEmail);
  if (!customerEmail) {
    alert("A valid email address is required to complete your purchase.");
    return;
  }

  const amountInKobo = Math.round(product.price * 100);
  const transactionRef = 'KODECX_' + Math.floor(Math.random() * 1000000000 + 1);

  // Pre-save pending order before checkout popup opens
  savePendingOrder(
    transactionRef,
    [{ ...product, name: product.title, downloadUrl: product.driveLink || '' }],
    {
      email: customerEmail,
      name: user?.displayName || 'Customer',
      reference: transactionRef
    }
  );

  if (onStart) onStart();

  try {
    const handler = window.PaystackPop.setup({
      key: PAYSTACK_PUBLIC_KEY,
      email: customerEmail,
      amount: amountInKobo,
      currency: 'NGN',
      ref: transactionRef,
      metadata: {
        user_id: user?.uid || '',
        product_id: product.id,
        product_title: product.title,
        customer_email: customerEmail
      },
      onClose: function() {
        if (onCancel) onCancel();
        alert('Transaction was cancelled.');
      },
      callback: function(response) {
        console.log('PAYSTACK SUCCESS:', response);

        (async () => {
          try {
            alert('Payment confirmed! Processing your source code confirmation email...');

            const emailResponse = await sendConfiguredPurchaseEmail({
              userEmail: customerEmail,
              orderId: response.reference || transactionRef,
              productTitle: product.title,
              downloadLink: product.driveLink || '',
              customerName: user?.displayName || 'Customer'
            });

            if (user?.uid) {
              await savePurchaseToFirestore(user.uid, [{
                title: product.title,
                link: product.driveLink || ''
              }]);
            }

            clearPendingOrder();

            alert(
              `EMAIL SENT ✓\n\nConfirmation accepted for: ${customerEmail}\nStatus: ${emailResponse.status}`
            );

            if (onSuccess) onSuccess({ product, reference: response.reference });

            if (isLinkInBioProduct(product)) {
              alert('Link In Bio download link has been sent to your email and is secured against unauthorized direct downloads.');
              return;
            }

            if (product.driveLink && product.driveLink.trim() !== '') {
              window.open(product.driveLink, '_blank');
            }
          } catch (err) {
            console.error("Payment was successful but email delivery failed:", err);
            alert(`Payment succeeded, but automated email failed: ${err.message}\nYour reference is: ${response.reference}`);
            if (onError) onError(err);

            if (!isLinkInBioProduct(product) && product.driveLink) {
              const confirmOpen = confirm("Would you like to open the source code download directly now?");
              if (confirmOpen) window.open(product.driveLink, '_blank');
            }
          }
        })();
      }
    });

    handler.openIframe();
  } catch (err) {
    console.error("Paystack launch error:", err);
    alert("Failed to initialize Paystack checkout: " + (err.message || String(err)));
    if (onError) onError(err);
  }
}

export function triggerCartPaystack({
  cart,
  user,
  onStart,
  onSuccess,
  onError,
  onCancel,
  clearCart
}) {
  if (!cart || cart.length === 0) return;

  if (typeof window.PaystackPop === 'undefined') {
    alert("Paystack SDK is loading or unavailable. Please check your network connection.");
    return;
  }

  let rawEmail = user?.email || prompt("Enter your email address to receive your order downloads:");
  if (!rawEmail) return;

  const customerEmail = sanitizeEmail(rawEmail);
  if (!customerEmail) {
    alert("A valid email address is required to complete your purchase.");
    return;
  }

  const totalNaira = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const amountInKobo = Math.round(totalNaira * 100);
  const transactionRef = 'KODECX_CART_' + Math.floor(Math.random() * 1000000000 + 1);

  const purchasedCart = cart.map(item => ({ ...item }));

  savePendingOrder(
    transactionRef,
    purchasedCart,
    {
      email: customerEmail,
      name: user?.displayName || 'Customer',
      reference: transactionRef
    }
  );

  if (onStart) onStart();

  try {
    const handler = window.PaystackPop.setup({
      key: PAYSTACK_PUBLIC_KEY,
      email: customerEmail,
      amount: amountInKobo,
      currency: 'NGN',
      ref: transactionRef,
      metadata: {
        user_id: user?.uid || '',
        cart_items: purchasedCart.map(item => item.id).join(','),
        customer_email: customerEmail
      },
      onClose: function() {
        if (onCancel) onCancel();
        alert('Transaction was cancelled.');
      },
      callback: function(response) {
        console.log('PAYSTACK CART SUCCESS:', response);

        (async () => {
          try {
            alert('Payment confirmed! Sending your automated confirmation emails...');

            const emailResult = await processMultiAccountCheckout(purchasedCart, {
              email: customerEmail,
              name: user?.displayName || 'Customer',
              reference: response.reference || transactionRef
            });

            if (user?.uid) {
              const itemsToSave = purchasedCart.map(i => ({
                title: i.title,
                link: i.driveLink || ''
              }));
              await savePurchaseToFirestore(user.uid, itemsToSave);
            }

            if (clearCart) clearCart();

            if (emailResult.failedItems.length > 0) {
              alert(
                `PARTIAL DELIVERY\n\nSent: ${emailResult.sentCount}\nFailed: ${emailResult.failedItems.join(', ')}`
              );
            } else {
              alert(`EMAILS SENT ✓\n\nConfirmation emails sent for ${emailResult.sentCount} template(s) to ${customerEmail}`);
              clearPendingOrder();
            }

            if (onSuccess) onSuccess({ cart: purchasedCart, reference: response.reference });

            const containsLinkInBio = purchasedCart.some(item => isLinkInBioProduct(item));
            if (containsLinkInBio) {
              alert('Notice: "Link In Bio" source code is delivered exclusively by email for security.');
            }

            const firstDownload = purchasedCart.find(item => item.driveLink && !isLinkInBioProduct(item));
            if (firstDownload) {
              window.open(firstDownload.driveLink, '_blank');
            }
          } catch (err) {
            console.error("Cart checkout error:", err);
            alert("Error processing cart delivery: " + err.message);
            if (onError) onError(err);
          }
        })();
      }
    });

    handler.openIframe();
  } catch (err) {
    console.error("Paystack Cart Checkout error:", err);
    alert("Could not initialize Paystack cart: " + err.message);
    if (onError) onError(err);
  }
}
