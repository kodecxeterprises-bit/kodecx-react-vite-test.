// Kodecx Enterprises - Full Digital Templates Catalog & EmailJS Configs

export const products = [
  {
    id: "p0",
    title: "ElectroDecor Store",
    category: "E-Commerce",
    emailjs: {
      service_id: "service_sfocxym",
      template_id: "template_jl0yvos",
      public_key: "40dhVQzrKc8Mu51TY"
    },
    price: 25000,
    description: "Modern storefront built for high conversion. Features product categories, clean modal showcases, and seamless WhatsApp ordering integration.",
    images: [
      "https://i.postimg.cc/m25MK6cg/Screenshot-2026-07-31-02-36-23-050-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/mrNPZdrQ/Screenshot-2026-07-31-02-38-11-890-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/7YGbJP61/Screenshot-2026-07-31-02-38-24-693-com-foxdebug-acodefree.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1Py2fZs1EgX0bAu3bl7uCjduBX07jF8yw/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20ElectroDecor%20Store"
    },
    features: [
      "Modular product catalog & categories",
      "One-click WhatsApp cart checkout",
      "High-speed image lightbox galleries",
      "Fully responsive mobile-first architecture",
      "Ready for direct deployment"
    ]
  },
  {
    id: "p1",
    title: "Apex Service Landing Page",
    category: "Business",
    emailjs: {
      service_id: "service_94wsukv",
      template_id: "template_6a1jgav",
      public_key: "iFJbiRyi3OlPX_na4"
    },
    price: 20000,
    description: "High-end landing page template for agencies and service providers. Features responsive pricing cards, cost estimator widget, and lead intake form.",
    images: [
      "https://i.postimg.cc/L5q4PvHm/Screenshot-2026-07-31-02-55-22-848-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/nLHH2nHT/Screenshot-2026-07-31-02-55-30-467-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/wMsHMvVM/Screenshot-2026-07-31-02-55-34-989-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/X7dGD70H/Screenshot-2026-07-31-02-55-38-077-com-foxdebug-acodefree.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1VLuPYfRG4T-dqI5Cyb_mxtiwUhsoEDrm/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Apex%20Service%20Landing%20Page"
    },
    features: [
      "Interactive cost estimator calculator",
      "Lead generation contact form",
      "Client testimonial slider section",
      "SEO optimized semantic tags",
      "Zero dependencies, pure lightweight code"
    ]
  },
  {
    id: "p2",
    title: "Link In Bio Profile Page",
    category: "Portfolio",
    emailjs: {
      service_id: "service_94wsukv",
      template_id: "template_cr9pxec",
      public_key: "iFJbiRyi3OlPX_na4"
    },
    price: 15000,
    description: "Ultra-fast bio link tree template customized for developers, producers, and creators. Includes interactive skill tags and link cards.",
    images: [
      "https://i.postimg.cc/sDYx46p8/Screenshot-2026-07-31-03-57-07-196-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/BnNvdj7d/Screenshot-2026-07-31-03-57-13-929-com-foxdebug-acodefree.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1Rc19CInsQPegEXTRLBLjHaRcFxbR6MeL/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Link%20In%20Bio%20Profile%20Page"
    },
    features: [
      "Social media multi-link cards",
      "Custom profile header with badges",
      "Audio / video portfolio embed ready",
      "Delivered via email confirmation",
      "Fastest mobile load times (<300ms)"
    ]
  },
  {
    id: "p3",
    title: "Apex Game Shop Site",
    category: "Gaming",
    emailjs: {
      service_id: "service_grznrxj",
      template_id: "template_xvyq1yl",
      public_key: "ipJj460QLhiG-XD13"
    },
    price: 30000,
    description: "Dynamic web layout crafted for gaming stores, top-up portals, and digital merchandise sales with modern dark UI styling.",
    images: [
      "https://i.postimg.cc/L6C7wRB0/Screenshot-2026-08-20-11-44-43-550-com-android-chrome.jpg",
      "https://i.postimg.cc/7hPstQ51/Screenshot-2026-08-20-11-44-50-836-com-android-chrome.jpg",
      "https://i.postimg.cc/pVk15x7r/Screenshot-2026-08-20-11-44-53-607-com-android-chrome.jpg"
    ],
    video: null,
    driveLink: "",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Apex%20Game%20Shop%20Site"
    },
    features: [
      "Cyberpunk dark-mode game aesthetics",
      "Virtual items and coins top-up grid",
      "Dynamic filtering for game genres",
      "Discord & community integration tabs",
      "Instant checkout UI flow"
    ]
  },
  {
    id: "p4",
    title: "Automotive Parts Sales Site",
    category: "Automotive",
    emailjs: {
      service_id: "service_grznrxj",
      template_id: "template_h0d30la",
      public_key: "ipJj460QLhiG-XD13"
    },
    price: 35000,
    description: "Professional automotive inventory showcase page designed for auto spare parts dealers, car accessories shops, and mechanics.",
    images: [
      "https://i.postimg.cc/L8vbLSht/Screenshot-2026-08-20-11-51-56-041-com-foxdebug-acodefree.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1Ucu3aFc-Cv4bRX5pacWYSRfqZI6Q3APT/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Automotive%20Parts%20Sales%20Site"
    },
    features: [
      "Vehicle model & parts filter search",
      "Technical specifications table",
      "Mechanic booking consultation modal",
      "High-res parts zoom preview",
      "WhatsApp ordering with pre-filled parts list"
    ]
  },
  {
    id: "p5",
    title: "Music Artist Portfolio Site",
    category: "Entertainment",
    emailjs: {
      service_id: "service_sfocxym",
      template_id: "template_0v1803c",
      public_key: "40dhVQzrKc8Mu51TY"
    },
    price: 10000,
    description: "Sleek portfolio layout built for musical artists, DJs, and producers to showcase releases, audio embeds, tour dates, and booking links.",
    images: [
      "https://i.postimg.cc/vH0rvZ7K/Screenshot-2026-08-20-12-02-51-006-com-android-chrome-2.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1NogL8jrgTQ9iHWD44dMgJzqbXV/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Music%20Artist%20Portfolio%20Site"
    },
    features: [
      "Spotify, Apple Music & Audiomack player embeds",
      "Tour dates & live tickets schedule",
      "Press kit / EPK download button",
      "Direct artist booking contact form",
      "Music video showcase grid"
    ]
  },
  {
    id: "p6",
    title: "Online Learning Platform",
    category: "Education",
    emailjs: {
      service_id: "service_q2hu18z",
      template_id: "template_ea9legk",
      public_key: "6KPPBivAlAHisS724"
    },
    price: 40000,
    description: "Comprehensive course catalog and LMS portal design ideal for tutors, online academies, and educational content creators.",
    images: [
      "https://i.postimg.cc/02ptwDBs/Screenshot-2026-08-26-06-49-49-057-com-android-chrome.jpg",
      "https://i.postimg.cc/yNWXvZvK/Screenshot-2026-08-26-06-49-55-929-com-android-chrome.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1xlJKJk3HEb4VEEIF5iM238Vm7xdqvmpw/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Online%20Learning%20Platform"
    },
    features: [
      "Curriculum course breakdown with accordion",
      "Instructor bio and student ratings",
      "Certificate of completion preview",
      "Enrollment registration form",
      "Video lecture preview player"
    ]
  },
  {
    id: "p8",
    title: "Trendit Socials",
    category: "Social Media",
    emailjs: {
      service_id: "service_1p4g4so",
      template_id: "template_3g93y5n",
      public_key: "SCkY1U94s93yoQdfO"
    },
    price: 100000,
    description: "Modern social media platform template built for creators, communities, and growing brands. Features a polished social feed experience with a clean, responsive interface designed for engaging users and showcasing content.",
    images: [
      "https://i.postimg.cc/Gpmq0Rzb/Screenshot-2026-09-26-18-42-40-371-com-foxdebug-acodefree.jpg"
    ],
    video: "https://yourimageshare.com/ib/PHFaaGjVt8.mp4",
    driveLink: "https://drive.google.com/file/d/11RWNCMuzKIwMoe3CojmeOPBmAgx64rxr/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Trendit%20Socials"
    },
    features: [
      "High-engagement interactive social feed",
      "Video stories and reel player integration",
      "Creator profile with followers count",
      "Post creation modal with image/video upload UI",
      "Real-time like and comment UI states"
    ]
  },
  {
    id: "p9",
    title: "Auto Car Dealers Site",
    category: "Automotive",
    emailjs: {
      service_id: "service_1p4g4so",
      template_id: "template_b01dyqw",
      public_key: "SCkY1U94s93yoQdfO"
    },
    price: 50000,
    description: "Professional car dealership website template designed for auto dealers and vehicle businesses. Showcases vehicles in a clean, modern layout with a strong presentation built to help customers browse and discover available cars.",
    images: [],
    video: "https://yourimageshare.com/ib/9xiCCnyx1j.mp4",
    driveLink: "https://drive.google.com/file/d/1hJZ1bbErC0e3d_a3W5GtjOJI4DpsrHYv/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Auto%20Car%20Dealers%20Site"
    },
    features: [
      "Dynamic video showcase of vehicles",
      "Mileage, fuel type & gearbox filters",
      "Schedule test drive appointment form",
      "Loan financing cost calculator",
      "Direct sales rep WhatsApp integration"
    ]
  },
  {
    id: "p7",
    title: "Furniture Store Showcase",
    category: "E-Commerce",
    emailjs: {
      service_id: "service_q2hu18z",
      template_id: "template_767olyh",
      public_key: "6KPPBivAlAHisS724"
    },
    price: 30000,
    description: "Elegant luxury layout customized for interior decorators, home furniture stores, and woodwork studios.",
    images: [
      "https://i.postimg.cc/TPHCr6MN/Screenshot-2026-08-26-07-47-55-411-com-foxdebug-acodefree-2.jpg",
      "https://i.postimg.cc/d0D9QxkQ/Screenshot-2026-08-26-07-48-02-754-com-foxdebug-acodefree.jpg",
      "https://i.postimg.cc/2ydQXpJK/Screenshot-2026-08-26-07-48-25-729-com-foxdebug-acodefree-2.jpg"
    ],
    video: null,
    driveLink: "https://drive.google.com/file/d/1YQ6oQltq2n6KxC9l4QcJh4BmLkEOGctu/view?usp=drivesdk",
    links: {
      whatsapp: "https://wa.me/2349071967004?text=Hello!%20I%20want%20to%20purchase%20the%20template:%20Furniture%20Store%20Showcase"
    },
    features: [
      "Room category browsing (Living, Bedroom, Office)",
      "High-res zoom texture inspection",
      "Material and fabric customization selectors",
      "Bulk order consultation request",
      "Direct WhatsApp checkout link"
    ]
  }
];

// Preserved EmailJS configuration map matching existing accounts
export const productsConfig = {
  "Apex Service Landing Page": {
    service_id: "service_94wsukv",
    template_id: "template_6a1jgav",
    public_key: "iFJbiRyi3OlPX_na4"
  },
  "Link In Bio Profile Page": {
    service_id: "service_94wsukv",
    template_id: "template_cr9pxec",
    public_key: "iFJbiRyi3OlPX_na4"
  },
  "Music Artist Portfolio Site": {
    service_id: "service_sfocxym",
    template_id: "template_0v1803c",
    public_key: "40dhVQzrKc8Mu51TY"
  },
  "ElectroDecor Store": {
    service_id: "service_sfocxym",
    template_id: "template_jl0yvos",
    public_key: "40dhVQzrKc8Mu51TY"
  },
  "Apex Game Shop Site": {
    service_id: "service_grznrxj",
    template_id: "template_xvyq1yl",
    public_key: "ipJj460QLhiG-XD13"
  },
  "Automotive Parts Sales Site": {
    service_id: "service_grznrxj",
    template_id: "template_h0d30la",
    public_key: "ipJj460QLhiG-XD13"
  },
  "Furniture Store Showcase": {
    service_id: "service_q2hu18z",
    template_id: "template_767olyh",
    public_key: "6KPPBivAlAHisS724"
  },
  "Online Learning Platform": {
    service_id: "service_q2hu18z",
    template_id: "template_ea9legk",
    public_key: "6KPPBivAlAHisS724"
  },
  "Trendit Socials": {
    service_id: "service_1p4g4so",
    template_id: "template_3g93y5n",
    public_key: "SCkY1U94s93yoQdfO"
  },
  "Auto Car Dealers Site": {
    service_id: "service_1p4g4so",
    template_id: "template_b01dyqw",
    public_key: "SCkY1U94s93yoQdfO"
  }
};
