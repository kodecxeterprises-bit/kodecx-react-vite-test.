import React, { useState, useEffect } from 'react';
import { products } from './data/products';
import { 
  defaultExchangeRates, 
  fetchLiveExchangeRates, 
  detectUserCurrency 
} from './services/currency';
import { 
  subscribeToAuth, 
  subscribeToUserPurchases 
} from './services/firebase';
import { 
  triggerSinglePaystack, 
  triggerCartPaystack 
} from './services/paystack';
import { recoverPendingOrder } from './services/recovery';

// Components
import { Banner } from './components/Banner';
import { Navbar } from './components/Navbar';
import { TrustStrip } from './components/TrustStrip';
import { ProductModal } from './components/ProductModal';
import { Lightbox } from './components/Lightbox';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { PurchasesDrawer } from './components/PurchasesDrawer';
import { DownloadZipModal } from './components/DownloadZipModal';
import { RagmyWidget } from './components/RagmyWidget';
import { TawkWidget } from './components/TawkWidget';
import { Footer } from './components/Footer';

// Pages
import { HomePage } from './pages/HomePage';
import { StorePage } from './pages/StorePage';
import { CustomServicesPage } from './pages/CustomServicesPage';
import { PortfolioPage } from './pages/PortfolioPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';

export function App() {
  // Navigation
  const [currentPage, setCurrentPage] = useState('home');

  // Currency
  const [currentCurrency, setCurrentCurrency] = useState('NGN');

  // Auth & User purchases
  const [currentUser, setCurrentUser] = useState(null);
  const [purchases, setPurchases] = useState([]);

  // Cart
  const [cart, setCart] = useState(() => {
    try {
      const saved = localStorage.getItem('kodecx_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals
  const [activeProduct, setActiveProduct] = useState(null);
  const [lightboxState, setLightboxState] = useState({
    active: false,
    product: null,
    initialIndex: 0
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isPurchasesOpen, setIsPurchasesOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Search prefill for Store
  const [storeSearch, setStoreSearch] = useState('');

  // Persist cart
  useEffect(() => {
    try {
      localStorage.setItem('kodecx_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn("Could not persist cart:", e);
    }
  }, [cart]);

  // Currency initialization & IP detection
  useEffect(() => {
    async function initCurrency() {
      await fetchLiveExchangeRates();
      const detected = await detectUserCurrency();
      if (detected && defaultExchangeRates[detected]) {
        setCurrentCurrency(detected);
      }
    }
    initCurrency();
  }, []);

  // Firebase auth & firestore purchases subscription
  useEffect(() => {
    let unsubscribePurchases = () => {};

    const unsubscribeAuth = subscribeToAuth((user) => {
      setCurrentUser(user);
      if (user) {
        unsubscribePurchases = subscribeToUserPurchases(user.uid, (items) => {
          setPurchases(items || []);
        });
      } else {
        setPurchases([]);
      }
    });

    return () => {
      unsubscribeAuth();
      unsubscribePurchases();
    };
  }, []);

  // Pending order recovery on app startup
  useEffect(() => {
    recoverPendingOrder(currentUser);
  }, [currentUser]);

  // Cart management
  const handleAddToCart = (product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId, newQuantity) => {
    if (newQuantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveFromCart = (productId) => {
    setCart((prev) => prev.filter((item) => item.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Paystack Checkouts
  const handleBuySinglePaystack = (product) => {
    triggerSinglePaystack({
      product,
      user: currentUser,
      onStart: () => {},
      onSuccess: ({ reference }) => {
        console.log("Paystack single success:", reference);
      },
      onError: (err) => {
        console.error("Paystack single error:", err);
      }
    });
  };

  const handleCartPaystackCheckout = () => {
    triggerCartPaystack({
      cart,
      user: currentUser,
      onStart: () => {},
      onSuccess: ({ reference }) => {
        console.log("Paystack cart success:", reference);
        setIsCartOpen(false);
      },
      onError: (err) => {
        console.error("Paystack cart error:", err);
      },
      clearCart: handleClearCart
    });
  };

  const handleOpenSearch = () => {
    setCurrentPage('store');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-orange-500 selection:text-white">
      {/* Announcement Banner */}
      <Banner onOpenDownloadModal={() => setIsDownloadModalOpen(true)} />

      {/* Primary Sticky Navbar */}
      <Navbar
        currentCurrency={currentCurrency}
        onCurrencyChange={setCurrentCurrency}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenPurchases={() => setIsPurchasesOpen(true)}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
        currentPage={currentPage}
        onNavigate={(page) => {
          setCurrentPage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenSearch={handleOpenSearch}
      />

      {/* Trust & Guarantee Strip */}
      <TrustStrip />

      {/* Main Page View */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            products={products}
            currentCurrency={currentCurrency}
            onOpenDetails={(p) => setActiveProduct(p)}
            onAddToCart={handleAddToCart}
            cart={cart}
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        )}

        {currentPage === 'store' && (
          <StorePage
            products={products}
            currentCurrency={currentCurrency}
            onOpenDetails={(p) => setActiveProduct(p)}
            onAddToCart={handleAddToCart}
            cart={cart}
            initialSearch={storeSearch}
          />
        )}

        {currentPage === 'services' && (
          <CustomServicesPage currentCurrency={currentCurrency} />
        )}

        {currentPage === 'portfolio' && (
          <PortfolioPage
            products={products}
            currentCurrency={currentCurrency}
            onOpenDetails={(p) => setActiveProduct(p)}
          />
        )}

        {currentPage === 'about' && (
          <AboutPage 
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage />
        )}
      </main>

      {/* Footer */}
      <Footer 
        onNavigate={(page) => {
          setCurrentPage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* Interactive Support Widgets */}
      <RagmyWidget />
      <TawkWidget />

      {/* Product Detail Modal */}
      <ProductModal
        product={activeProduct}
        currentCurrency={currentCurrency}
        onClose={() => setActiveProduct(null)}
        onBuyWithPaystack={handleBuySinglePaystack}
        onAddToCart={handleAddToCart}
        isInCart={cart.some((item) => item.id === activeProduct?.id)}
        onOpenLightbox={(prod, idx) => {
          setLightboxState({ active: true, product: prod, initialIndex: idx });
        }}
      />

      {/* Fullscreen Media Lightbox */}
      <Lightbox
        active={lightboxState.active}
        product={lightboxState.product}
        initialIndex={lightboxState.initialIndex}
        onClose={() => setLightboxState({ active: false, product: null, initialIndex: 0 })}
      />

      {/* Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        currentCurrency={currentCurrency}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onCheckoutPaystack={handleCartPaystackCheckout}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
        }}
      />

      {/* Purchased Downloads Drawer */}
      <PurchasesDrawer
        isOpen={isPurchasesOpen}
        onClose={() => setIsPurchasesOpen(false)}
        purchases={purchases}
      />

      {/* Download Project Source Code ZIP Modal */}
      <DownloadZipModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}

export default App;
