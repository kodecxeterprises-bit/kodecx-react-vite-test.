// Pending Paystack Order Recovery Service

import { processMultiAccountCheckout } from "./emailjs";
import { savePurchaseToFirestore } from "./firebase";

export const PAYSTACK_VERIFY_ENDPOINT = 
  import.meta.env.VITE_PAYSTACK_VERIFY_ENDPOINT || "/api/paystack/verify";

const PENDING_ORDER_KEY = "kodecx_pending_order";
const PENDING_ORDER_MAX_AGE = 24 * 60 * 60 * 1000; // 24 hours

export function savePendingOrder(reference, cartItems, customerDetails) {
  const pendingData = {
    reference,
    cartItems,
    customerDetails,
    timestamp: Date.now()
  };
  try {
    localStorage.setItem(PENDING_ORDER_KEY, JSON.stringify(pendingData));
    console.log("Pending order saved to localStorage:", reference);
  } catch (err) {
    console.error("Could not save pending order:", err);
  }
}

export function clearPendingOrder() {
  try {
    localStorage.removeItem(PENDING_ORDER_KEY);
    console.log("Pending order cleared from localStorage.");
  } catch (err) {
    console.error("Could not clear pending order:", err);
  }
}

export async function recoverPendingOrder(currentUser) {
  let savedOrder = null;
  try {
    savedOrder = localStorage.getItem(PENDING_ORDER_KEY);
  } catch (err) {
    console.error("Could not read pending order:", err);
    return;
  }

  if (!savedOrder) return;

  try {
    const pendingData = JSON.parse(savedOrder);
    if (!pendingData || !pendingData.reference || !pendingData.timestamp ||
        !Array.isArray(pendingData.cartItems) || !pendingData.customerDetails) {
      clearPendingOrder();
      return;
    }

    if (Date.now() - pendingData.timestamp > PENDING_ORDER_MAX_AGE) {
      console.log("Pending order expired:", pendingData.reference);
      clearPendingOrder();
      return;
    }

    console.log("Checking pending transaction ref:", pendingData.reference);

    const verifyUrl = `${PAYSTACK_VERIFY_ENDPOINT.replace(/\/$/, '')}/${encodeURIComponent(pendingData.reference)}`;
    const response = await fetch(verifyUrl, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });

    if (!response.ok) {
      console.warn("Backend verify returned status:", response.status);
      return;
    }

    const resData = await response.json();
    if (resData && resData.status && resData.data && resData.data.status === 'success') {
      if (window.__kodecxRecoveryRunning) return;
      window.__kodecxRecoveryRunning = true;

      try {
        const result = await processMultiAccountCheckout(
          pendingData.cartItems,
          pendingData.customerDetails
        );

        if (result && result.sentCount > 0) {
          if (currentUser?.uid) {
            await savePurchaseToFirestore(
              currentUser.uid,
              pendingData.cartItems.map(item => ({
                title: item.title || item.name || 'Purchased Template',
                link: item.driveLink || item.downloadUrl || ''
              }))
            );
          }

          clearPendingOrder();
          alert(
            `Welcome back! Payment for reference ${pendingData.reference} was verified and your product emails have been dispatched.`
          );
        }
      } finally {
        window.__kodecxRecoveryRunning = false;
      }
    }
  } catch (err) {
    console.error("Error during pending order recovery:", err);
  }
}
