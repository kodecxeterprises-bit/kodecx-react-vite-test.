import React, { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

export function Lightbox({
  active,
  product,
  initialIndex,
  onClose
}) {
  const [currentIndex, setCurrentIndex] = React.useState(initialIndex || 0);

  useEffect(() => {
    setCurrentIndex(initialIndex || 0);
  }, [initialIndex]);

  if (!active || !product) return null;

  const mediaList = [];
  if (product.video) {
    mediaList.push({ type: 'video', src: product.video });
  }
  (product.images || []).forEach((img) => {
    if (img) mediaList.push({ type: 'image', src: img });
  });

  const currentMedia = mediaList[currentIndex] || mediaList[0];

  const handlePrev = (e) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + mediaList.length) % mediaList.length);
  };

  const handleNext = (e) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % mediaList.length);
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={onClose}
    >
      <button 
        onClick={onClose}
        className="absolute top-5 right-5 text-slate-400 hover:text-white p-2 rounded-full bg-slate-900/80 border border-slate-800 cursor-pointer z-50 transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      {mediaList.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-800 cursor-pointer z-50 transition-all hover:scale-110"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-800 cursor-pointer z-50 transition-all hover:scale-110"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </>
      )}

      {/* Main Display */}
      <div 
        className="max-w-5xl max-h-[80vh] flex items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        {currentMedia?.type === 'video' ? (
          <video 
            src={currentMedia.src} 
            controls 
            autoPlay 
            playsInline 
            className="max-w-[92vw] max-h-[80vh] rounded-2xl shadow-2xl object-contain bg-black"
          />
        ) : (
          <img 
            src={currentMedia?.src} 
            alt="Fullscreen preview" 
            className="max-w-[92vw] max-h-[80vh] rounded-2xl shadow-2xl object-contain"
          />
        )}
      </div>

      <div className="mt-4 text-center">
        <h4 className="text-white font-bold text-sm">{product.title}</h4>
        <p className="text-slate-400 text-xs mt-0.5">
          {currentIndex + 1} of {mediaList.length}
        </p>
      </div>
    </div>
  );
}
