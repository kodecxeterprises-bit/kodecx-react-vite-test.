import React, { useState } from 'react';
import { 
  X, 
  FileCode, 
  Download, 
  CheckCircle2, 
  Copy, 
  Terminal, 
  ExternalLink,
  ShieldCheck,
  FolderTree
} from 'lucide-react';

export function DownloadZipModal({ isOpen, onClose }) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const quickStartCommand = "unzip kodecx-react-vite.zip && cd kodecx-react-vite && npm install && npm run dev";

  const handleCopy = () => {
    navigator.clipboard.writeText(quickStartCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800/80 rounded-full cursor-pointer transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400">
            <FileCode className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">Download Project Source Code (.ZIP)</h3>
            <p className="text-xs text-slate-400">
              Complete, self-contained React + Vite project archive ready for development or deployment.
            </p>
          </div>
        </div>

        {/* Deliverable Info */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300">Archive Name:</span>
            <span className="font-mono text-orange-400 font-bold">kodecx-react-vite.zip</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300">Format:</span>
            <span className="text-slate-400">Folder &lsquo;kodecx-react-vite/&rsquo; root structure</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300">Included Integrations:</span>
            <span className="text-emerald-400 font-semibold">Paystack, Firebase, EmailJS, Multi-Currency</span>
          </div>
        </div>

        {/* Direct Download Button */}
        <a
          href="/kodecx-react-vite.zip"
          download="kodecx-react-vite.zip"
          className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-extrabold py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/20 cursor-pointer text-sm"
        >
          <Download className="w-4 h-4" />
          <span>Download &ldquo;kodecx-react-vite.zip&rdquo; Now</span>
        </a>

        {/* Terminal Run Guide */}
        <div>
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
            Run Locally in 1 Command
          </label>
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-2 text-xs font-mono text-slate-300">
            <span className="truncate">{quickStartCommand}</span>
            <button
              onClick={handleCopy}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 cursor-pointer transition-colors"
              title="Copy command"
            >
              {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <p className="text-[11px] text-slate-500 text-center">
          Verified with Vite 6, Tailwind CSS v4, and React 19. Ready for one-click deployment on Netlify or Vercel.
        </p>
      </div>
    </div>
  );
}
