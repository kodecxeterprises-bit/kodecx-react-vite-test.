import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Download, 
  User, 
  Menu, 
  X, 
  FileCode, 
  Sparkles,
  Layers,
  Briefcase,
  Info,
  PhoneCall,
  Search
} from 'lucide-react';
import { currencyNames } from '../services/currency';

export function Navbar({
  currentCurrency,
  onCurrencyChange,
  cartCount,
  onOpenCart,
  currentUser,
  onOpenAuth,
  onOpenPurchases,
  onOpenDownloadModal,
  currentPage,
  onNavigate,
  onOpenSearch
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'store', label: 'Templates Store' },
    { id: 'services', label: 'Custom Development' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-xl border-b border-orange-500/30 shadow-lg shadow-black/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
        {/* Brand */}
        <div 
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group flex-shrink-0"
        >
          <div className="relative">
            <img 
              src="https://i.ibb.co/3yyH3cKS/1781110845060.png" 
              alt="Kodecx Logo" 
              className="w-9 h-9 rounded-full object-cover border-2 border-orange-500 shadow-md group-hover:scale-105 transition-transform"
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-slate-950"></span>
          </div>
          <div className="leading-tight">
            <span className="text-lg font-black tracking-tight text-white flex items-center gap-1">
              Kodecx<span className="text-orange-500">Enterprises</span>
            </span>
            <span className="block text-[10px] uppercase font-bold tracking-widest text-slate-400">
              Web & App Engineering
            </span>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center gap-1 text-sm font-medium">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                currentPage === link.id
                  ? 'bg-orange-500/10 text-orange-400 font-semibold border border-orange-500/20'
                  : 'text-slate-300 hover:text-white hover:bg-slate-900/80'
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Currency Dropdown */}
          <div className="relative">
            <select
              value={currentCurrency}
              onChange={(e) => onCurrencyChange(e.target.value)}
              className="bg-slate-900 hover:bg-slate-800 text-white border border-slate-700 rounded-full px-2.5 py-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer transition-colors shadow-inner"
            >
              {Object.entries(currencyNames).map(([code, label]) => (
                <option key={code} value={code} className="bg-slate-900 text-white">
                  {label}
                </option>
              ))}
            </select>
          </div>

          {/* Search Trigger */}
          <button
            onClick={onOpenSearch}
            title="Search Templates"
            className="p-1.5 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-full cursor-pointer transition-colors"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Downloads Button (If logged in) */}
          {currentUser && (
            <button
              onClick={onOpenPurchases}
              className="hidden sm:inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-orange-400" />
              <span>Downloads</span>
            </button>
          )}

          {/* Auth Button */}
          <button
            onClick={onOpenAuth}
            className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer"
          >
            <User className="w-3.5 h-3.5 text-orange-400" />
            <span className="hidden sm:inline">
              {currentUser ? (currentUser.displayName || currentUser.email?.split('@')[0]) : 'Sign In'}
            </span>
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative inline-flex items-center gap-1.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-md shadow-orange-500/20 transition-all cursor-pointer"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Cart</span>
            {cartCount > 0 && (
              <span className="inline-flex items-center justify-center bg-white text-orange-600 font-extrabold text-[10px] w-4 h-4 rounded-full ml-0.5">
                {cartCount}
              </span>
            )}
          </button>

          {/* Project ZIP Download (Direct deliverable trigger) */}
          <button
            onClick={onOpenDownloadModal}
            title="Download complete React+Vite ZIP package"
            className="hidden xl:inline-flex items-center gap-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5 text-emerald-400" />
            <span>kodecx.zip</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 text-slate-300 hover:text-white bg-slate-900 rounded-lg border border-slate-800 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950 border-b border-slate-800 px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                currentPage === link.id
                  ? 'bg-orange-500/20 text-orange-400'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              {link.label}
            </button>
          ))}
          <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
            {currentUser && (
              <button
                onClick={() => { onOpenPurchases(); setMobileMenuOpen(false); }}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-slate-200 hover:bg-slate-900 font-semibold"
              >
                <Download className="w-4 h-4 text-orange-400" />
                <span>My Downloads</span>
              </button>
            )}
            <button
              onClick={() => { onOpenDownloadModal(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 font-semibold"
            >
              <FileCode className="w-4 h-4 text-emerald-400" />
              <span>Download Project ZIP (kodecx-react-vite.zip)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
