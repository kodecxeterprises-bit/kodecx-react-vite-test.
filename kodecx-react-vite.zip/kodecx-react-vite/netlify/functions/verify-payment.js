// Netlify Serverless Function for Secure Paystack Transaction Verification
// Validates payments directly with Paystack API using server-side PAYSTACK_SECRET_KEY

exports.handler = async (event) => {
  const reference = event.queryStringParameters?.reference || 
                    event.path.split('/').pop();

  if (!reference) {
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: false, message: "Transaction reference is required" }),
    };
  }

  const secretKey = process.env.PAYSTACK_SECRET_KEY;

  if (!secretKey) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        status: false, 
        message: "PAYSTACK_SECRET_KEY environment variable is not configured on the server." 
      }),
    };
  }

  try {
    const paystackRes = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${secretKey}`,
        "Content-Type": "application/json",
      },
    });

    const data = await paystackRes.json();

    return {
      statusCode: paystackRes.status,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(data),
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: false, message: error.message || "Paystack verification request failed" }),
    };
  }
};
