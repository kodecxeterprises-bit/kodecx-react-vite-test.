// Firebase Authentication and Firestore Service

import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from "firebase/auth";
import { 
  getFirestore, 
  doc, 
  setDoc, 
  arrayUnion, 
  onSnapshot 
} from "firebase/firestore";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBv_y6Cmib1G6CUqEEte0pvEKfbuOB8F3A",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "kodecx.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "kodecx",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "kodecx.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "391188791",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:391188791:web:f68ac4be17497e9b2f0ab2",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-83DREMY24Z"
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

export async function loginWithGoogle() {
  return await signInWithPopup(auth, googleProvider);
}

export async function loginWithEmail(email, password) {
  return await signInWithEmailAndPassword(auth, email.trim(), password);
}

export async function registerWithEmail(email, password) {
  return await createUserWithEmailAndPassword(auth, email.trim(), password);
}

export async function logoutUser() {
  return await signOut(auth);
}

export function subscribeToAuth(callback) {
  return onAuthStateChanged(auth, callback);
}

export async function savePurchaseToFirestore(userId, purchasedItems) {
  if (!userId || !purchasedItems || purchasedItems.length === 0) return;
  try {
    const userDocRef = doc(db, "users", userId);
    const stampedItems = purchasedItems.map(item => ({
      title: item.title || item.name || "Purchased Template",
      link: item.driveLink || item.link || item.downloadUrl || "",
      purchasedAt: new Date().toISOString()
    }));
    await setDoc(userDocRef, {
      purchases: arrayUnion(...stampedItems)
    }, { merge: true });
    console.log("Firestore purchase record updated successfully for user:", userId);
  } catch (err) {
    console.error("Failed to save purchase record to Firestore:", err);
  }
}

export function subscribeToUserPurchases(userId, callback) {
  if (!userId) return () => {};
  const userDocRef = doc(db, "users", userId);
  return onSnapshot(userDocRef, (docSnap) => {
    if (docSnap.exists()) {
      const data = docSnap.data();
      callback(data.purchases || []);
    } else {
      callback([]);
    }
  }, (err) => {
    console.warn("Firestore purchase listener error:", err);
    callback([]);
  });
}
