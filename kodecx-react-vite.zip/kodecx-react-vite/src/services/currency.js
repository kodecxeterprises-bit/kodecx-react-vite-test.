// Multi-Currency Exchange Rates and Conversion Service

export const defaultExchangeRates = {
  NGN: 1,
  USD: 0.00067,
  GHS: 0.010,
  ZAR: 0.012,
  KES: 0.086
};

export const currencySymbols = {
  NGN: '₦',
  USD: '$',
  GHS: '₵',
  ZAR: 'R',
  KES: 'KSh'
};

export const currencyNames = {
  NGN: '🇳🇬 NGN (₦)',
  USD: '🇺🇸 USD ($)',
  GHS: '🇬🇭 GHS (₵)',
  ZAR: '🇿🇦 ZAR (R)',
  KES: '🇰🇪 KES (KSh)'
};

let liveRates = { ...defaultExchangeRates };

export async function fetchLiveExchangeRates() {
  try {
    const rateRes = await fetch('https://open.er-api.com/v6/latest/NGN');
    const rateData = await rateRes.json();
    if (rateData && rateData.rates) {
      liveRates.USD = rateData.rates.USD || liveRates.USD;
      liveRates.GHS = rateData.rates.GHS || liveRates.GHS;
      liveRates.ZAR = rateData.rates.ZAR || liveRates.ZAR;
      liveRates.KES = rateData.rates.KES || liveRates.KES;
    }
  } catch (err) {
    console.warn('Live rates fetch failed, using fallback exchange rates.', err);
  }
  return liveRates;
}

export async function detectUserCurrency() {
  try {
    const ipRes = await fetch('https://ipapi.co/json/');
    const ipData = await ipRes.json();
    if (ipData && ipData.currency && defaultExchangeRates[ipData.currency]) {
      return ipData.currency;
    }
  } catch (err) {
    console.warn('IP location detection failed, defaulting to NGN.', err);
  }
  return 'NGN';
}

export function convertPrice(priceInNaira, currency) {
  const rate = liveRates[currency] || defaultExchangeRates[currency] || 1;
  const converted = priceInNaira * rate;
  return currency === 'NGN' ? Math.round(converted) : Number(converted.toFixed(2));
}

export function formatPrice(priceInNaira, currency) {
  const amount = convertPrice(priceInNaira, currency);
  const symbol = currencySymbols[currency] || '₦';
  return `${symbol}${amount.toLocaleString()}`;
}
