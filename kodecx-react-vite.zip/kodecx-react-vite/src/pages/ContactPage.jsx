import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MessageSquare, 
  Clock, 
  Send, 
  CheckCircle2, 
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    const waText = `Hello Kodecx Enterprises!\n\nName: ${name}\nEmail: ${email}\nMessage: ${message}`;
    window.open(`https://wa.me/2349071967004?text=${encodeURIComponent(waText)}`, '_blank');
    setSent(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-12">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-orange-400 bg-orange-500/10 border border-orange-500/20 px-3.5 py-1.5 rounded-full">
          Get in Touch
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          Direct Developer Support
        </h1>
        <p className="text-sm text-slate-300 leading-relaxed">
          Need assistance with your template download, paystack transaction verification, or want to discuss a custom application build? Reach out anytime.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Contact info cards */}
        <div className="lg:col-span-5 space-y-4">
          <a
            href="https://wa.me/2349071967004"
            target="_blank"
            rel="noopener noreferrer"
            className="block bg-slate-900 border border-slate-800 hover:border-emerald-500/50 p-6 rounded-3xl transition-all hover:-translate-y-0.5 group"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase text-slate-500 block">Fastest Response</span>
                <h4 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">
                  WhatsApp Direct
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">+234 907 196 7004</p>
              </div>
            </div>
          </a>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-1">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase text-slate-500 block">Email Inquiries</span>
                <h4 className="text-base font-bold text-white">contact@kodecx.com</h4>
                <p className="text-xs text-slate-400 mt-0.5">Automated confirmation delivery support</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-1">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold uppercase text-slate-500 block">Support Hours</span>
                <h4 className="text-base font-bold text-white">Monday &ndash; Saturday</h4>
                <p className="text-xs text-slate-400 mt-0.5">8:00 AM &ndash; 10:00 PM (WAT)</p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <h3 className="text-xl font-bold text-white tracking-tight">Send a Direct Message</h3>
          
          {sent ? (
            <div className="p-6 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <h4 className="text-sm font-bold text-white">Opening WhatsApp Chat...</h4>
              <p className="text-xs text-slate-300">
                Your message has been pre-formatted for direct delivery to our development team.
              </p>
              <button
                onClick={() => setSent(false)}
                className="mt-2 text-xs font-bold text-orange-400 underline cursor-pointer"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Your Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex Johnson"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Your Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Message or Project Scope</label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your inquiry, template question, or custom build requirements..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs text-white focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-extrabold py-3.5 px-6 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20 transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Send to Developer via WhatsApp</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
