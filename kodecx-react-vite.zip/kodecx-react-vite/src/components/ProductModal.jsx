import React, { useState } from 'react';
import { 
  X, 
  ShoppingCart, 
  ExternalLink, 
  Maximize2, 
  CreditCard, 
  MessageSquare, 
  CheckCircle2, 
  FileCode,
  ShieldCheck,
  Zap,
  Play
} from 'lucide-react';
import { formatPrice } from '../services/currency';

export function ProductModal({
  product,
  currentCurrency,
  onClose,
  onBuyWithPaystack,
  onAddToCart,
  isInCart,
  onOpenLightbox
}) {
  const [selectedMediaIdx, setSelectedMediaIdx] = useState(0);

  if (!product) return null;

  const mediaList = [];
  if (product.video) {
    mediaList.push({ type: 'video', src: product.video });
  }
  (product.images || []).forEach((img) => {
    if (img) mediaList.push({ type: 'image', src: img });
  });

  const activeMedia = mediaList[selectedMediaIdx] || mediaList[0];

  const waText = `Hello! I want to purchase the template: ${product.title} (${formatPrice(product.price, currentCurrency)})`;
  const waUrl = `https://wa.me/2349071967004?text=${encodeURIComponent(waText)}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <span className="bg-orange-500/20 text-orange-400 border border-orange-500/30 text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-md">
              {product.category}
            </span>
            <span className="text-xs text-slate-400 font-medium">Verified Codebase</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-full cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Main Media Showcase */}
          <div className="space-y-3">
            <div 
              onClick={() => onOpenLightbox(product, selectedMediaIdx)}
              className="relative w-full h-72 sm:h-96 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 cursor-zoom-in group"
            >
              {activeMedia?.type === 'video' ? (
                <video 
                  src={activeMedia.src} 
                  controls 
                  autoPlay 
                  muted 
                  loop 
                  playsInline 
                  className="w-full h-full object-cover"
                />
              ) : (
                <img 
                  src={activeMedia?.src || 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&q=80'} 
                  alt={product.title} 
                  className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                />
              )}

              <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-md text-white text-xs font-semibold px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-1.5 opacity-90 group-hover:opacity-100 transition-opacity">
                <Maximize2 className="w-3.5 h-3.5 text-orange-400" />
                <span>Tap to expand fullscreen</span>
              </div>
            </div>

            {/* Thumbnails row */}
            {mediaList.length > 1 && (
              <div className="flex gap-2.5 overflow-x-auto pb-1">
                {mediaList.map((m, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedMediaIdx(idx)}
                    className={`relative w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-all cursor-pointer ${
                      selectedMediaIdx === idx 
                        ? 'border-orange-500 scale-105 shadow-md shadow-orange-500/20' 
                        : 'border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    {m.type === 'video' ? (
                      <div className="w-full h-full bg-slate-950 flex items-center justify-center text-white">
                        <Play className="w-5 h-5 text-orange-400" />
                      </div>
                    ) : (
                      <img src={m.src} alt="Thumb" className="w-full h-full object-cover" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Title, Price, Description */}
          <div className="space-y-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-slate-800/80 pb-4">
              <div>
                <h2 className="text-2xl font-black text-white tracking-tight">{product.title}</h2>
                <span className="text-xs text-slate-400">Complete pre-built package ready for immediate deployment</span>
              </div>
              <div className="text-right">
                <span className="text-xs uppercase font-bold text-slate-500 block">Instant Price</span>
                <span className="text-3xl font-black text-orange-500 tracking-tight">
                  {formatPrice(product.price, currentCurrency)}
                </span>
              </div>
            </div>

            {/* Description Card */}
            <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-2xl">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Overview & Architecture
              </h4>
              <p className="text-sm text-slate-300 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Key Included Features */}
            {product.features && (
              <div className="bg-slate-950/70 border border-slate-800/80 p-4 rounded-2xl">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-orange-400" />
                  <span>Key Features Included</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                  {product.features.map((f, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <span className="text-orange-500 font-bold">&bull;</span>
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Security Notice */}
            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-950/40 p-3 rounded-xl border border-slate-800/40">
              <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>
                Payment is secured with 256-bit encryption. Automated confirmation email and download links are dispatched upon payment approval.
              </span>
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="p-6 bg-slate-950/80 border-t border-slate-800 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => onBuyWithPaystack(product)}
            className="flex-1 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black py-3.5 px-6 rounded-2xl shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
          >
            <CreditCard className="w-4 h-4" />
            <span>Pay {formatPrice(product.price, currentCurrency)} with Paystack</span>
          </button>

          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 px-5 rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Buy via WhatsApp</span>
          </a>

          <button
            onClick={() => onAddToCart(product)}
            className={`py-3.5 px-5 rounded-2xl font-bold border flex items-center justify-center gap-2 transition-all cursor-pointer text-sm ${
              isInCart
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
            }`}
          >
            <ShoppingCart className="w-4 h-4 text-orange-400" />
            <span>{isInCart ? 'In Cart' : 'Add to Cart'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
