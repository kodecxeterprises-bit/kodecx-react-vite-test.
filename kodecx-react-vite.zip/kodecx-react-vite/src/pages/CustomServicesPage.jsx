import React, { useState } from 'react';
import { 
  Code2, 
  Globe, 
  Smartphone, 
  Database, 
  CheckCircle2, 
  Calculator, 
  MessageSquare, 
  ArrowRight,
  ShieldCheck,
  Zap,
  Layers,
  Palette
} from 'lucide-react';
import { formatPrice } from '../services/currency';

export function CustomServicesPage({ currentCurrency }) {
  const [projectType, setProjectType] = useState('full-site');
  const [hasAuth, setHasAuth] = useState(true);
  const [hasPayment, setHasPayment] = useState(true);
  const [hasCMS, setHasCMS] = useState(false);
  const [pageCount, setPageCount] = useState(5);

  // Dynamic estimate calculation in Naira
  const basePrices = {
    'landing': 50000,
    'full-site': 120000,
    'ecommerce': 180000,
    'web-app': 250000
  };

  let estimatedNaira = basePrices[projectType] || 100000;
  estimatedNaira += pageCount * 10000;
  if (hasAuth) estimatedNaira += 30000;
  if (hasPayment) estimatedNaira += 35000;
  if (hasCMS) estimatedNaira += 40000;

  const waQuoteText = `Hello Kodecx! I calculated an estimate for a custom project:
- Type: ${projectType}
- Pages: ${pageCount}
- Features: ${hasAuth ? 'Auth, ' : ''}${hasPayment ? 'Payment Gateway, ' : ''}${hasCMS ? 'CMS/Admin' : 'Standard'}
- Estimated Budget: ${formatPrice(estimatedNaira, currentCurrency)}

I'd like to discuss building this project!`;

  const waQuoteUrl = `https://wa.me/2349071967004?text=${encodeURIComponent(waQuoteText)}`;

  const services = [
    {
      icon: Globe,
      title: "Bespoke Full-Stack Websites",
      desc: "Tailored multi-page corporate portals and high-performance digital experiences with responsive architectures."
    },
    {
      icon: ShoppingCartIcon,
      title: "Custom E-Commerce Platforms",
      desc: "High-conversion online stores with integrated multi-currency, Paystack checkout, WhatsApp order intake, and inventory tools."
    },
    {
      icon: Smartphone,
      title: "Mobile-First Progressive Web Apps",
      desc: "Installable PWAs engineered with offline capabilities, lightning load speeds, and intuitive touch UX."
    },
    {
      icon: Database,
      title: "Firebase & Backend Integrations",
      desc: "Cloud Firestore schemas, user authentication, security rules, and real-time database synchronization."
    },
    {
      icon: Palette,
      title: "UI/UX Redesign & Modernization",
      desc: "Transform outdated interfaces into sleek, dark/light modern designs with crisp Tailwind CSS components."
    },
    {
      icon: Zap,
      title: "Speed Optimization & SEO",
      desc: "Sub-second loading times, clean semantic markup, social share metadata, and high Core Web Vitals scores."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-orange-400 bg-orange-500/10 border border-orange-500/20 px-3.5 py-1.5 rounded-full">
          Custom Development Services
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
          We Build Custom Websites & Web Applications
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          From tailored landing pages to enterprise full-stack web platforms. Kodecx Enterprises turns your requirements into high-speed, secure, production-ready code.
        </p>
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s, idx) => (
          <div 
            key={idx}
            className="bg-slate-900/80 border border-slate-800 hover:border-orange-500/40 p-6 rounded-3xl space-y-3 transition-all hover:-translate-y-1 shadow-lg"
          >
            <div className="w-12 h-12 rounded-2xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
              <s.icon className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">{s.title}</h3>
            <p className="text-xs text-slate-400 leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>

      {/* Interactive Project Cost Estimator */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8">
        <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-400">
              <Calculator className="w-4 h-4" />
              <span>Interactive Quote Calculator</span>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight mt-1">
              Estimate Your Custom Build
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-medium">Transparent, honest baseline estimation</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Controls */}
          <div className="space-y-6">
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                1. Select Solution Scope
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'landing', label: 'Single Landing Page' },
                  { id: 'full-site', label: 'Multi-Page Business Site' },
                  { id: 'ecommerce', label: 'E-Commerce Storefront' },
                  { id: 'web-app', label: 'Custom Web Application' },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setProjectType(opt.id)}
                    className={`p-3 rounded-2xl border text-left text-xs font-bold transition-all cursor-pointer ${
                      projectType === opt.id
                        ? 'bg-orange-500/20 border-orange-500 text-orange-400'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-slate-300 mb-2">
                <span>2. Estimated Number of Views / Pages</span>
                <span className="text-orange-400">{pageCount} Pages</span>
              </div>
              <input
                type="range"
                min="1"
                max="20"
                value={pageCount}
                onChange={(e) => setPageCount(Number(e.target.value))}
                className="w-full accent-orange-500 cursor-pointer"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                3. Integrations & Advanced Capabilities
              </label>
              <div className="space-y-2">
                {[
                  { state: hasAuth, setter: setHasAuth, label: 'Firebase User Authentication & Profiles' },
                  { state: hasPayment, setter: setHasPayment, label: 'Paystack Payment Gateway & Invoicing' },
                  { state: hasCMS, setter: setHasCMS, label: 'Admin Dashboard / Content Management System' },
                ].map((item, i) => (
                  <label
                    key={i}
                    className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700 transition-colors"
                  >
                    <input
                      type="checkbox"
                      checked={item.state}
                      onChange={(e) => item.setter(e.target.checked)}
                      className="accent-orange-500 w-4 h-4 rounded cursor-pointer"
                    />
                    <span className="text-xs font-semibold text-slate-300">{item.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Result Card */}
          <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Estimated Project Investment
              </span>
              <div className="text-4xl sm:text-5xl font-black text-orange-500 tracking-tight">
                {formatPrice(estimatedNaira, currentCurrency)}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Estimate includes complete responsive frontend, API integrations, production deployment, and 30 days of post-launch maintenance.
              </p>

              <div className="pt-4 border-t border-slate-800 space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>100% full source code ownership</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Optimized for desktop, tablet, and mobile</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Direct developer WhatsApp communication</span>
                </div>
              </div>
            </div>

            <a
              href={waQuoteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black py-4 px-6 rounded-2xl shadow-xl shadow-orange-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Discuss This Estimate on WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function ShoppingCartIcon(props) {
  return (
    <svg 
      {...props} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <circle cx="8" cy="21" r="1"/>
      <circle cx="19" cy="21" r="1"/>
      <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>
    </svg>
  );
}
