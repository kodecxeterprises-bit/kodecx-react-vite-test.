import React from 'react';
import { 
  ArrowRight, 
  Sparkles, 
  Zap, 
  Code2, 
  ShieldCheck, 
  MessageSquare, 
  Flame, 
  Layers, 
  ExternalLink,
  ChevronRight,
  Headphones,
  FileCheck,
  CheckCircle2,
  TrendingUp,
  Download
} from 'lucide-react';
import { ProductCard } from '../components/ProductCard';
import { formatPrice } from '../services/currency';

export function HomePage({
  products,
  currentCurrency,
  onOpenDetails,
  onAddToCart,
  cart,
  onNavigate,
  onOpenDownloadModal
}) {
  const featured = products.slice(0, 4);

  return (
    <div className="space-y-16 pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-6">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(255,71,0,0.18),rgba(255,255,255,0))]"></div>
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-orange-600/10 blur-[130px] rounded-full pointer-events-none -z-10"></div>

        <div className="max-w-5xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 bg-slate-900/90 border border-orange-500/30 px-3.5 py-1.5 rounded-full text-xs font-bold text-orange-400 shadow-lg shadow-orange-500/10 animate-pulse-glow">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>KODECX ENTERPRISES &bull; OFFICIAL TEMPLATES REPOSITORY</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-[1.1] max-w-4xl mx-auto">
            High-Converting <span className="bg-gradient-to-r from-orange-500 via-amber-400 to-red-500 bg-clip-text text-transparent">Web Templates</span> & Custom App Builds
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Acquire pristine, pre-built source code packages ready for instant production deployment. Backed by verified Paystack checkout, Google Drive downloads, and direct developer WhatsApp assistance.
          </p>

          {/* Call to Actions */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onNavigate('store')}
              className="bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black py-3.5 px-7 rounded-2xl shadow-xl shadow-orange-500/25 flex items-center gap-2 text-sm transition-all hover:scale-105 cursor-pointer"
            >
              <span>Explore All Templates</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('services')}
              className="bg-slate-900 hover:bg-slate-800 text-white border border-slate-700 font-bold py-3.5 px-6 rounded-2xl text-sm transition-all hover:border-slate-600 cursor-pointer flex items-center gap-2"
            >
              <Code2 className="w-4 h-4 text-orange-400" />
              <span>Request Custom Website</span>
            </button>

            <button
              onClick={onOpenDownloadModal}
              className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-bold py-3.5 px-5 rounded-2xl text-sm transition-all cursor-pointer flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Download Project ZIP</span>
            </button>
          </div>

          {/* Quick Metrics Bar */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto text-left border-t border-slate-800/80">
            <div className="bg-slate-900/60 border border-slate-800/60 p-3.5 rounded-2xl">
              <span className="text-2xl font-black text-white">10+</span>
              <span className="text-[11px] text-slate-400 block font-medium">Production Templates</span>
            </div>
            <div className="bg-slate-900/60 border border-slate-800/60 p-3.5 rounded-2xl">
              <span className="text-2xl font-black text-orange-400">100%</span>
              <span className="text-[11px] text-slate-400 block font-medium">Clean Source Code</span>
            </div>
            <div className="bg-slate-900/60 border border-slate-800/60 p-3.5 rounded-2xl">
              <span className="text-2xl font-black text-emerald-400">⚡ Instant</span>
              <span className="text-[11px] text-slate-400 block font-medium">Drive & Email Delivery</span>
            </div>
            <div className="bg-slate-900/60 border border-slate-800/60 p-3.5 rounded-2xl">
              <span className="text-2xl font-black text-amber-400">24/7</span>
              <span className="text-[11px] text-slate-400 block font-medium">WhatsApp Assistance</span>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Templates Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2 text-orange-400 text-xs font-bold uppercase tracking-wider">
              <Flame className="w-4 h-4 fill-current" />
              <span>Handcrafted Solutions</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1">
              Featured Web Templates
            </h2>
          </div>
          <button
            onClick={() => onNavigate('store')}
            className="text-xs font-bold text-orange-400 hover:text-orange-300 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <span>View All {products.length} Templates</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              currentCurrency={currentCurrency}
              onOpenDetails={onOpenDetails}
              onAddToCart={onAddToCart}
              isInCart={cart.some((item) => item.id === p.id)}
            />
          ))}
        </div>
      </section>

      {/* Custom Build Banner CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900 to-orange-950/60 border-2 border-orange-500/40 rounded-3xl p-8 sm:p-12 shadow-2xl">
          <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-orange-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="max-w-2xl space-y-4">
            <span className="bg-orange-500/20 text-orange-400 text-[10px] font-extrabold uppercase px-3 py-1 rounded-full border border-orange-500/30">
              Tailored Engineering
            </span>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              Need a Custom Website or Application?
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Have specific business requirements, custom backend needs, or require a bespoke design from scratch? Kodecx Enterprises builds tailored, scalable solutions for startups and growing enterprises.
            </p>
            <div className="pt-2 flex flex-wrap gap-3">
              <a
                href="https://wa.me/2349071967004?text=Hello!%20I%20want%20a%20custom%20website."
                target="_blank"
                rel="noopener noreferrer"
                className="bg-orange-500 hover:bg-orange-600 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-lg shadow-orange-500/20 text-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp (+234 907 196 7004)</span>
              </a>
              <button
                onClick={() => onNavigate('services')}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold py-3.5 px-5 rounded-2xl text-xs transition-colors cursor-pointer"
              >
                View Services & Pricing
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Kodecx */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-orange-400 text-xs font-bold uppercase tracking-wider">
            Enterprise Value
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Why Professionals Choose Kodecx
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Engineered for developers, founders, and agencies who prioritize code purity and speed.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-3xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Instant Fulfillment</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Upon successful Paystack checkout, your download link is dispatched automatically via multi-account EmailJS and logged in your Firestore purchase history.
            </p>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-3xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Code2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Zero Vendor Lock-in</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              You own the full source code completely. Clean markup, modular components, zero bloat, and standard npm tooling ready for any cloud host.
            </p>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-3xl space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Headphones className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Direct Developer Backing</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Got setup questions? Need tailored feature additions? Reach out directly via WhatsApp for quick troubleshooting and consultation.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
