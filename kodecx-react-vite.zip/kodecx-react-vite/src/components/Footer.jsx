import React from 'react';
import { 
  Heart, 
  ExternalLink, 
  ShieldCheck, 
  Code2, 
  MessageSquare,
  Mail,
  Phone
} from 'lucide-react';

export function Footer({ onNavigate, onOpenDownloadModal }) {
  const socials = [
    { name: "Facebook", icon: "📘", url: "https://www.facebook.com/profile.php?id=61590596795646" },
    { name: "LinkedIn", icon: "💼", url: "https://www.linkedin.com/in/chijioke-igbo-545672424?utm_source=share_via&utm_content=profile&utm_medium=member_android" },
    { name: "Instagram", icon: "📸", url: "https://www.instagram.com/kodec_x_enterprises?igsh=OGZyeDBhdXZlcGhp&igsi=OGZyeDBhdXZlcGhp" },
    { name: "X (Twitter)", icon: "🐦", url: "https://x.com/kodec_x" },
    { name: "TikTok", icon: "🎵", url: "https://tiktok.com/@kodec.x" },
    { name: "YouTube", icon: "▶️", url: "https://youtube.com/@kodecxenterprises?si=D4QvNkXTb8xFslZz" },
    { name: "WhatsApp", icon: "💬", url: "https://wa.me/2349071967004" }
  ];

  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 pt-12 pb-8 px-4 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <img 
                src="https://i.ibb.co/3yyH3cKS/1781110845060.png" 
                alt="Logo" 
                className="w-7 h-7 rounded-full border border-orange-500" 
              />
              <span className="text-base font-black text-white">Kodecx<span className="text-orange-500">Enterprises</span></span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Premium digital website templates and bespoke web application engineering. High conversion, ultra-fast loading, and instant source code delivery.
            </p>
            <div className="flex items-center gap-2 text-slate-300 font-semibold text-[11px]">
              <Phone className="w-3.5 h-3.5 text-orange-400" />
              <span>+234 907 196 7004</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-sm tracking-wide">Explore</h4>
            <ul className="space-y-1.5">
              <li><button onClick={() => onNavigate('store')} className="hover:text-orange-400 cursor-pointer">Templates Store</button></li>
              <li><button onClick={() => onNavigate('services')} className="hover:text-orange-400 cursor-pointer">Custom Web Development</button></li>
              <li><button onClick={() => onNavigate('portfolio')} className="hover:text-orange-400 cursor-pointer">Live Projects Portfolio</button></li>
              <li><button onClick={() => onNavigate('about')} className="hover:text-orange-400 cursor-pointer">About Kodecx</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-orange-400 cursor-pointer">Contact & Support</button></li>
            </ul>
          </div>

          {/* Project Architecture */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-sm tracking-wide">Developer Suite</h4>
            <ul className="space-y-1.5">
              <li>
                <button 
                  onClick={onOpenDownloadModal} 
                  className="text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer flex items-center gap-1"
                >
                  <span>Download kodecx-react-vite.zip</span>
                </button>
              </li>
              <li><span className="text-slate-500">React 19 &bull; Vite 6 &bull; Tailwind CSS</span></li>
              <li><span className="text-slate-500">Paystack Verified Transactions</span></li>
              <li><span className="text-slate-500">EmailJS Multi-Account Engines</span></li>
              <li><span className="text-slate-500">Firebase Cloud Firestore Sync</span></li>
            </ul>
          </div>

          {/* Direct Support */}
          <div className="space-y-2">
            <h4 className="text-white font-bold text-sm tracking-wide">Direct Consultation</h4>
            <p className="text-slate-400 leading-relaxed">
              Need a bespoke custom web application, API integration, or mobile-first storefront?
            </p>
            <a
              href="https://wa.me/2349071967004?text=Hello!%20I%20want%20a%20custom%20website."
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-3.5 rounded-xl transition-all cursor-pointer mt-2"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Social Buttons */}
        <div className="pt-6 border-t border-slate-900 space-y-3 text-center">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
            Official Social & Community Channels
          </span>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {socials.map((s, idx) => (
              <a
                key={idx}
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-200 px-3 py-1.5 rounded-full text-xs font-semibold transition-all hover:scale-105"
              >
                <span>{s.icon}</span>
                <span>{s.name}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-6 border-t border-slate-900/80 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <span>&copy; 2026 Kodecx Enterprises. All Rights Reserved.</span>
          <span>Engineered with React + Vite &bull; Secure Paystack Payments</span>
        </div>
      </div>
    </footer>
  );
}
