import React from 'react';
import { ExternalLink, ShoppingCart, Code2, Play, CheckCircle2, Eye } from 'lucide-react';
import { formatPrice } from '../services/currency';

export function PortfolioPage({
  products,
  currentCurrency,
  onOpenDetails
}) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-12">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-orange-400 bg-orange-500/10 border border-orange-500/20 px-3.5 py-1.5 rounded-full">
          Verified Kodecx Projects & Solutions
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          Production-Ready Architecture Showcase
        </h1>
        <p className="text-sm text-slate-300 leading-relaxed">
          Explore genuine Kodecx project builds across E-Commerce, Social Media, Automotive, Entertainment, and Agency landing pages. Every project is ready for immediate deployment or customization.
        </p>
      </div>

      {/* Portfolio Grid */}
      <div className="space-y-8">
        {products.map((item, idx) => (
          <div
            key={item.id}
            className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-0 hover:border-orange-500/40 transition-colors"
          >
            {/* Media column */}
            <div 
              onClick={() => onOpenDetails(item)}
              className="lg:col-span-7 relative bg-slate-950 h-72 sm:h-96 overflow-hidden cursor-pointer group"
            >
              {item.video ? (
                <video 
                  src={item.video} 
                  muted 
                  loop 
                  playsInline 
                  autoPlay 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
              ) : (
                <img 
                  src={item.images?.[0] || 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&q=80'} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
              <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-md border border-slate-700/60 text-orange-400 text-xs font-bold px-3 py-1 rounded-lg">
                {item.category}
              </div>
              <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-1.5 opacity-90 group-hover:opacity-100">
                <Eye className="w-3.5 h-3.5 text-orange-400" />
                <span>Inspect Media & Features</span>
              </div>
            </div>

            {/* Details column */}
            <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="flex items-baseline justify-between gap-2">
                  <h3 className="text-xl font-bold text-white tracking-tight">{item.title}</h3>
                  <span className="text-base font-black text-orange-400">
                    {formatPrice(item.price, currentCurrency)}
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {item.description}
                </p>

                {item.features && (
                  <div className="space-y-1.5 pt-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      Architecture Highlights
                    </span>
                    <ul className="space-y-1 text-xs text-slate-300">
                      {item.features.slice(0, 3).map((f, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-orange-400 flex-shrink-0" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-800 flex flex-wrap gap-2">
                <button
                  onClick={() => onOpenDetails(item)}
                  className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-colors cursor-pointer text-center"
                >
                  View Details & Buy
                </button>
                <a
                  href={`https://wa.me/2349071967004?text=Hello!%20I%20am%20interested%20in%20customizing%20${encodeURIComponent(item.title)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold py-2.5 px-3.5 rounded-xl text-xs transition-colors cursor-pointer"
                >
                  Request Customization
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
