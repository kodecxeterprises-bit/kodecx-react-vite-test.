import React, { useState } from 'react';
import { Eye, ShoppingCart, Play, Check, ExternalLink } from 'lucide-react';
import { formatPrice } from '../services/currency';

export function ProductCard({
  product,
  currentCurrency,
  onOpenDetails,
  onAddToCart,
  isInCart
}) {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);

  const previewImage = product.images?.[0] || 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&q=80';

  return (
    <div 
      className="group relative bg-slate-900/90 border border-slate-800 hover:border-orange-500/50 rounded-2xl overflow-hidden flex flex-col shadow-lg shadow-black/40 hover:shadow-orange-500/10 transition-all duration-300 hover:-translate-y-1"
    >
      {/* Media Preview Box */}
      <div 
        onClick={() => onOpenDetails(product)}
        className="relative w-full h-48 bg-slate-950 overflow-hidden cursor-pointer"
        onMouseEnter={() => setIsVideoPlaying(true)}
        onMouseLeave={() => setIsVideoPlaying(false)}
      >
        {product.video ? (
          <div className="relative w-full h-full">
            <video 
              src={product.video} 
              muted 
              loop 
              playsInline 
              autoPlay={false}
              ref={(el) => {
                if (el) {
                  if (isVideoPlaying) el.play().catch(() => {});
                  else el.pause();
                }
              }}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 border border-white/10">
              <Play className="w-2.5 h-2.5 fill-current text-orange-400" />
              <span>Preview Video</span>
            </div>
          </div>
        ) : (
          <img 
            src={previewImage} 
            alt={product.title} 
            loading="lazy"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity"></div>

        {/* Category Pill */}
        <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md border border-slate-700/60 text-orange-400 font-extrabold text-[11px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow-sm">
          {product.category}
        </div>

        {/* Quick View Hover Button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px]">
          <span className="inline-flex items-center gap-1.5 bg-orange-500 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-lg">
            <Eye className="w-3.5 h-3.5" />
            <span>Inspect Template</span>
          </span>
        </div>
      </div>

      {/* Info & Purchase Area */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h3 
            onClick={() => onOpenDetails(product)}
            className="text-base font-bold text-white hover:text-orange-400 transition-colors line-clamp-1 cursor-pointer"
          >
            {product.title}
          </h3>
          <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        <div className="pt-4 mt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Price</span>
            <span className="text-lg font-black text-orange-500 tracking-tight">
              {formatPrice(product.price, currentCurrency)}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onAddToCart(product)}
              title={isInCart ? "In your cart" : "Add to Cart"}
              className={`p-2.5 rounded-xl border font-bold text-xs flex items-center gap-1 transition-all cursor-pointer ${
                isInCart
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                  : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200 hover:text-white'
              }`}
            >
              {isInCart ? <Check className="w-4 h-4" /> : <ShoppingCart className="w-4 h-4 text-orange-400" />}
            </button>

            <button
              onClick={() => onOpenDetails(product)}
              className="bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold py-2.5 px-3.5 rounded-xl transition-all shadow-md shadow-orange-500/20 cursor-pointer"
            >
              Details
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
