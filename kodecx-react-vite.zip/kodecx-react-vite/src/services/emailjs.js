// Multi-Account EmailJS Checkout Automation Service

import { productsConfig } from "../data/products";

export function isLinkInBioProduct(prod) {
  if (!prod) return false;
  const id = String(prod.id || '').trim().toLowerCase();
  const title = String(prod.title || prod.name || '').trim().toLowerCase();
  return id === 'p2' || title === 'link in bio profile page' || title.includes('link in bio');
}

export async function sendConfiguredPurchaseEmail({ userEmail, orderId, productTitle, downloadLink, customerName }) {
  const itemName = String(productTitle || '').trim();
  const config = productsConfig[itemName];

  if (!config) {
    throw new Error('No EmailJS configuration mapped for: ' + itemName);
  }
  if (!config.service_id || !config.template_id || !config.public_key) {
    throw new Error('Incomplete EmailJS configuration for: ' + itemName);
  }

  const email = String(userEmail || '').trim().toLowerCase();
  if (!email || !email.includes('@')) {
    throw new Error('A valid recipient email is required.');
  }

  const payload = {
    service_id: config.service_id,
    template_id: config.template_id,
    user_id: config.public_key,
    template_params: {
      email: email,
      to_email: email,
      user_email: email,
      reply_to: email,
      to_name: String(customerName || 'Valued Customer'),
      product_name: itemName,
      product_link: downloadLink || '#',
      order_id: String(orderId || 'KODECX_' + Date.now())
    }
  };

  const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorText = await response.text();
    const error = new Error(errorText || `EmailJS HTTP ${response.status}`);
    error.status = response.status;
    error.text = errorText;
    throw error;
  }

  return { status: response.status, text: await response.text() };
}

export async function processMultiAccountCheckout(cartItems, customerDetails) {
  let sentCount = 0;
  let failedItems = [];

  if (!customerDetails || !customerDetails.email) {
    return { sentCount: 0, failedItems: ["Missing Customer Email"] };
  }
  if (!cartItems || cartItems.length === 0) {
    return { sentCount: 0, failedItems: ["Cart Empty"] };
  }

  for (const item of cartItems) {
    const rawName = item.name || item.title || item.productName || "";
    const productName = rawName.trim();
    const config = productsConfig[productName];

    if (!config) {
      console.warn(`No EmailJS config mapped for: "${productName}"`);
      failedItems.push(`${productName || 'Unknown Item'} (Missing Config Map)`);
      continue;
    }

    const payload = {
      service_id: config.service_id,
      template_id: config.template_id,
      user_id: config.public_key,
      template_params: {
        email: customerDetails.email,
        to_email: customerDetails.email,
        user_email: customerDetails.email,
        reply_to: customerDetails.email,
        to_name: customerDetails.name || "Customer",
        product_name: productName,
        product_link: item.downloadUrl || item.driveLink || config.downloadUrl || "#",
        order_id: customerDetails.reference || "REF_" + Date.now()
      }
    };

    try {
      const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        sentCount++;
        console.log(`[SUCCESS] Email sent for: ${productName}`);
      } else {
        const errorText = await response.text();
        console.error(`[FAILED] ${productName}:`, errorText);
        failedItems.push(`${productName} (${errorText})`);
      }
    } catch (fetchError) {
      console.error(`[NETWORK ERROR] ${productName}:`, fetchError);
      failedItems.push(`${productName} (Network Error)`);
    }

    // 1.1s rate limiting delay
    await new Promise((resolve) => setTimeout(resolve, 1100));
  }

  return { sentCount, failedItems };
}
